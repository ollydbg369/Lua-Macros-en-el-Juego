script_author("Jos�")
local imgui = require 'mimgui'
local temas = require 'themes'
local encoding = require 'encoding'
encoding.default = 'iso-8859-1'
local u8 = encoding.UTF8
local ffi = require 'ffi'
local new, str, sizeof = imgui.new, ffi.string, ffi.sizeof
local inputmt = new.char[2048]()
local window = new.bool(false)
local inicfg = require 'inicfg'
local dir = 'macros_v2'
local cfg = inicfg.load({
    Settings = {
        cmd = 'macros',
        selected = 1,
        Theme = 1,
    }}, dir)
    inicfg.save(cfg, dir)

    local _r, key = pcall(require, 'vkeys')
    assert(_r, "vkeys.lua not found")

    local jsoncfg = {
        save = function(data, path)
            if doesFileExist(path) then os.remove(path) end
            if type(data) ~= 'table' then return end
            local f = io.open(path, 'a+')
            local writing_data = encodeJson(data)
            f:write(writing_data)
            f:close()
        end,
        load = function(path)
            if doesFileExist(path) then
                local f = io.open(path, 'r')
                local data = decodeJson(f:read('*a'))
                f:close()
                return data
            end
        end
    }

    local lista = getWorkingDirectory() .. "\\config/lista_macros.txt"
    local int_item = new.int(cfg.Settings.selected)
    local item_list = {}
    if not doesFileExist(lista) then jsoncfg.save(item_list, lista) else item_list = jsoncfg.load(lista) end

    local combo_names = {}
    for k, v in ipairs(item_list) do
        if v.nombre ~= nil then
            table.insert(combo_names, v.nombre)

        end
    end
    local ImItems = imgui.new['const char*'][#combo_names](combo_names)

    if item_list[int_item[0] + 1] ~= nil then
        imgui.StrCopy(inputmt, tostring(item_list[int_item[0] + 1].input))
    end

    local nombreperfil = new.char[100]("")

    function main()
        repeat wait(0) until isSampAvailable()
        sampRegisterChatCommand(cfg.Settings.cmd, function()
            window[0] = not window[0]
        end)

        while true do wait(0)
            for k, v in ipairs(item_list) do
                if isKeyDown(v.tecla1) and wasKeyPressed(v.tecla2) and not sampIsCursorActive() then
                    for lines in v.input:gmatch("[^\n]+") do
                        if not lines:match("{%d+}") then

                            if not v.Type then
                                sampProcessChatInput(u8:decode(lines))

                            else
                                sampSetChatInputEnabled(true)
                                sampSetChatInputText(u8:decode(lines))
                            end
                        end

                        local time = lines:match("{(%d+)}")
                        if time then

                            wait(time)
                        end
                    end
                end
            end
        end
    end

    local function getDownKeys()
        local down = ""
        for i = 0, 255 do
            if wasKeyPressed(i) and i ~= 0x5B and i ~= 0x5C then
                down = i
            end
        end
        return down
    end

    local function change_activate_button()
        lua_thread.create(function()
            wait(500)
            while true do
                wait(0)
                printString("Presiona la tecla #1 a establecer", 100)
                local downKey = getDownKeys()
                if downKey ~= '' then
                    item_list[int_item[0] + 1].tecla1 = downKey
                    jsoncfg.save(item_list, lista)

                    break
                end
            end
            while true do
                wait(0)
                printString("Presiona la tecla #2 a establecer", 100)
                local downKey = getDownKeys()
                if downKey ~= '' then
                    item_list[int_item[0] + 1].tecla2 = downKey
                    jsoncfg.save(item_list, lista)
                    break
                end
            end
        end)
    end

    local fa = require "fAwesome5"
    local color_selected = new.int(cfg.Settings.Theme)
    imgui.OnInitialize(function()
        if cum == nil then
            local glyph_ranges = imgui.GetIO().Fonts:GetGlyphRangesDefault()
            cum = imgui.GetIO().Fonts:AddFontFromFileTTF(getFolderPath(0x14) .. '\\segoeui.ttf', 18, nil, glyph_ranges)

        end

        local config = imgui.ImFontConfig()
        config.MergeMode = true
        config.PixelSnapH = true
        local iconRanges = new.ImWchar[3](fa.min_range, fa.max_range, 0)
        f = imgui.GetIO().Fonts:AddFontFromFileTTF('moonloader/lib/fa-solid-900.ttf', 11.0, config, iconRanges)

        temas.SwitchColorTheme(color_selected[0] + 1, imgui)
      
    end)

    local function separate()
        if color_selected[0] == 14 then
            imgui.Separator()
        end
    end

    local rename
    local coloritems = imgui.new['const char*'][#temas.colorThemes](temas.colorThemes)

    local multimacros
    if item_list[int_item[0] + 1] ~= nil then

        multimacros = new.bool(item_list[int_item[0] + 1].Type)
    else
        multimacros = new.bool(false)
    end

    local function update()
        imgui.StrCopy(inputmt, tostring(item_list[int_item[0] + 1].input))
        multimacros[0] = item_list[int_item[0] + 1].Type
    end

    imgui.OnFrame(
        function() return window[0] end,
        function(player)
            if #item_list <= 0 then
                imgui.StrCopy(inputmt, "")
            end
            local x, y = getScreenResolution()
            imgui.SetNextWindowPos(imgui.ImVec2(x / 2, y / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
            imgui.SetNextWindowSize(imgui.ImVec2(515, 450), imgui.Cond.FirstUseEver)
            imgui.PushFont(f)
            imgui.PushFont(cum)
            imgui.Begin(fa.ICON_FA_KEYBOARD..' Macros', window, imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoScrollbar)

            if item_list[int_item[0] + 1] ~= nil then
                imgui.Text(string.format("Teclas configuradas: %s + %s", item_list[int_item[0] + 1].tecla1 > 0 and key.id_to_name(item_list[int_item[0] + 1].tecla1) or "Ninguno", item_list[int_item[0] + 1].tecla2 > 0 and key.id_to_name(item_list[int_item[0] + 1].tecla2) or "Ninguno"))

            else
                imgui.Text("Teclas configuradas: Ninguno")
            end
            imgui.SameLine()
            if imgui.Checkbox("Solo abrir el chat", multimacros) then
                if item_list[int_item[0] + 1] ~= nil then
                    item_list[int_item[0] + 1].Type = multimacros[0]
                    jsoncfg.save(item_list, lista)
                end
            end
            separate()
            if imgui.Combo("##mc", int_item, ImItems, #combo_names) then
                cfg.Settings.selected = int_item[0]
                inicfg.save(cfg, dir)
                update()
            end
            imgui.SameLine()
            if imgui.Button("+ Agregar nuevo") then
                imgui.OpenPopup('+ Agregar nuevo')
            end
            separate()

            if imgui.InputTextMultiline("##in", inputmt, sizeof(inputmt), imgui.ImVec2(-1, color_selected[0] == 14 and - 29 or - 25)) then
                if item_list[int_item[0] + 1] ~= nil then
                    item_list[int_item[0] + 1].input = str(inputmt)
                end
            end
            separate()
            if imgui.Button("Guardar cambios") then
                if item_list[int_item[0] + 1] ~= nil then
                    item_list[int_item[0] + 1].input = str(inputmt)
                    jsoncfg.save(item_list, lista)
                    printStringNow("Configuracion guardada", 800)
                end
            end
            imgui.SameLine()
            if imgui.Button("Modificar") then
                if item_list[int_item[0] + 1] ~= nil then

                    rename = false
                    imgui.OpenPopup('Modificar')

                end
            end
            imgui.SameLine()
            if imgui.Button("Eliminar") and item_list[int_item[0] + 1] ~= nil then
                imgui.OpenPopup(u8'�Est�s seguro de eliminarlo?')

            end
            imgui.SameLine()
            if imgui.Button("Acerca de") then
                sampAddChatMessage("{78cfff}www.youtube.com/JoseSampMods/videos", -1)
            end

            imgui.PushItemWidth(75)

            imgui.SameLine()

            if imgui.Combo("##bg", color_selected, coloritems, #temas.colorThemes) then
                --sampAddChatMessage(color_selected[0]+1, -1)
                temas.SwitchColorTheme(color_selected[0] + 1, imgui)
                cfg.Settings.Theme = color_selected[0]
                inicfg.save(cfg, dir)
            end
            imgui.PopItemWidth()

            if imgui.BeginPopupModal(u8'�Est�s seguro de eliminarlo?', nil, imgui.WindowFlags.NoResize) then
                if imgui.Button("Si", imgui.ImVec2(85, 25)) then
                    table.remove(item_list, int_item[0] + 1)
                    table.remove(combo_names, int_item[0] + 1)
                    if int_item[0] > 0 then
                        int_item[0] = int_item[0] - 1
                    end
                    jsoncfg.save(item_list, lista)
                    inicfg.save(cfg, dir)
                    imgui.CloseCurrentPopup()
                    if #item_list > 0 then
                        imgui.StrCopy(inputmt, tostring(item_list[int_item[0] + 1].input))
                    end
                    ImItems = nil

                    ImItems = imgui.new['const char*'][#combo_names](combo_names)

                end
                imgui.SameLine()
                if imgui.Button("No", imgui.ImVec2(85, 25)) then
                    imgui.CloseCurrentPopup()
                end
            end
            if imgui.BeginPopup('+ Agregar nuevo') then

                imgui.Text("Ingresa un nombre para el macro")
                imgui.PushItemWidth(165) --establecer tama�o comboBox
                separate()
                imgui.InputText("###newa", nombreperfil, sizeof(nombreperfil))
                separate()
                if imgui.Button("Agregar") and #str(nombreperfil) > 0 then

                    table.insert(item_list, {nombre = str(nombreperfil), tecla1 = 0, tecla2 = 0, input = "", Type = false})
                    jsoncfg.save(item_list, lista)
                    combo_names = {}
                    for k, v in ipairs(item_list) do
                        if v.nombre ~= nil then

                            table.insert(combo_names, v.nombre)
                        end
                    end

                    ImItems = nil
                    int_item[0] = #combo_names - 1
                    update()

                    ImItems = imgui.new['const char*'][#combo_names](combo_names)

                    imgui.CloseCurrentPopup()
                    imgui.StrCopy(nombreperfil, "")
                end

                imgui.SameLine()
                if imgui.Button("Cancelar") then
                    imgui.CloseCurrentPopup()
                end

            end

            if imgui.BeginPopup('Modificar') then

                if not rename then

                    if imgui.Button("Cambiar nombre") then

                        rename = true

                    end
                    if imgui.Button("Cambiar teclas") then
                        change_activate_button()
                        imgui.CloseCurrentPopup()
                    end
                else
                    imgui.Text("Ingresa el nuevo nombre para el macro")
                    separate()
                    if imgui.InputText("###newa", nombreperfil, sizeof(nombreperfil)) then

                    end
                    separate()
                    if imgui.Button("Aceptar") and #str(nombreperfil) > 0 then
                        item_list[int_item[0] + 1].nombre = str(nombreperfil)
                        combo_names[int_item[0] + 1] = str(nombreperfil)

                        ImItems = nil

                        ImItems = imgui.new['const char*'][#combo_names](combo_names)

                        jsoncfg.save(item_list, lista)
                        imgui.CloseCurrentPopup()
                    end
                    imgui.SameLine()

                    if imgui.Button("Cancelar") then
                        imgui.CloseCurrentPopup()
                    end
                end

            end

            imgui.PopFont()
            imgui.End()

        end)
        
